import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import logoImage from '../assets/logo.png';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  
  // Handle scroll effect for header background opacity
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  // Animate navbar links
  const navVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };
  
  const linkVariants = {
    hidden: { opacity: 0, y: -20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <header className={`fixed w-full z-50 transition-colors duration-300 ${scrolled ? 'bg-[#172032]/90' : 'bg-[#111827]/70'} backdrop-blur-md`}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <a href="#" className="flex items-center space-x-2 p-1 bg-white/10 backdrop-blur-sm rounded-md">
            <img src={logoImage} alt="Techmostphere Logo" className="h-10" />
          </a>
          
          {/* Desktop Navigation */}
          <motion.nav 
            className="hidden md:flex items-center space-x-8"
            initial="hidden"
            animate="visible"
            variants={navVariants}
          >
            <motion.a href="#services" className="text-sm font-medium hover:text-accent-pink transition-colors" variants={linkVariants}>Services</motion.a>
            <motion.a href="#portfolio" className="text-sm font-medium hover:text-accent-orange transition-colors" variants={linkVariants}>Portfolio</motion.a>
            <motion.a href="#about" className="text-sm font-medium hover:text-accent-pink transition-colors" variants={linkVariants}>About</motion.a>
            <motion.a href="#testimonials" className="text-sm font-medium hover:text-accent-purple transition-colors" variants={linkVariants}>Testimonials</motion.a>
            <motion.a href="mailto:Sales@techmostphere.com" className="gradient-border px-4 py-2 text-sm font-medium bg-primary-dark hover:bg-secondary-dark transition-colors" variants={linkVariants}>Contact Us</motion.a>
          </motion.nav>
          
          {/* Mobile Navigation Toggle */}
          <button 
            className="md:hidden text-white focus:outline-none" 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'} text-xl`}></i>
          </button>
        </div>
        
        {/* Mobile Navigation Menu */}
        <motion.div 
          className={`md:hidden ${isMenuOpen ? 'block' : 'hidden'}`}
          initial={{ opacity: 0, height: 0 }}
          animate={{ 
            opacity: isMenuOpen ? 1 : 0, 
            height: isMenuOpen ? 'auto' : 0 
          }}
          transition={{ duration: 0.3 }}
        >
          <div className="glass mt-2 p-4 rounded-lg flex flex-col space-y-4">
            <a href="#services" onClick={() => setIsMenuOpen(false)} className="text-sm font-medium hover:text-accent-pink transition-colors">Services</a>
            <a href="#portfolio" onClick={() => setIsMenuOpen(false)} className="text-sm font-medium hover:text-accent-orange transition-colors">Portfolio</a>
            <a href="#about" onClick={() => setIsMenuOpen(false)} className="text-sm font-medium hover:text-accent-pink transition-colors">About</a>
            <a href="#testimonials" onClick={() => setIsMenuOpen(false)} className="text-sm font-medium hover:text-accent-purple transition-colors">Testimonials</a>
            <a href="mailto:Sales@techmostphere.com" onClick={() => setIsMenuOpen(false)} className="gradient-border px-4 py-2 text-center text-sm font-medium bg-primary-dark hover:bg-secondary-dark transition-colors">Contact Us</a>
          </div>
        </motion.div>
      </div>
    </header>
  );
};

export default Header;
