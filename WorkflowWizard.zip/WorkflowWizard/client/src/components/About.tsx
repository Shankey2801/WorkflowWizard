import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const technologies = {
  ai: ['TensorFlow', 'PyTorch', 'Scikit-learn', 'NLTK'],
  mobile: ['React Native', 'Flutter', 'Swift', 'Kotlin'],
  web: ['React.js', 'Node.js', 'Next.js', 'GraphQL'],
  backend: ['Python', 'Java', 'Go', 'Node.js'],
  cloud: ['AWS', 'Google Cloud', 'Azure', 'Firebase'],
  ecommerce: ['Shopify', 'WooCommerce', 'Magento', 'Odoo']
};

const About = () => {
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, amount: 0.2 });
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  return (
    <section id="about" className="py-20 md:py-32 relative overflow-hidden" ref={sectionRef}>
      <div className="absolute -left-64 bottom-1/4 w-96 h-96 bg-accent-purple rounded-full blur-[150px] opacity-10"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="inline-block font-poppins font-bold text-3xl sm:text-4xl mb-4 pb-2 border-b-2 border-accent-purple">
            About Techmostphere
          </h2>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            We're a team of passionate technologists building innovative solutions for tomorrow's challenges.
          </p>
        </motion.div>
        
        <motion.div 
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          <motion.div 
            className="glass rounded-xl p-8 animate-float"
            variants={itemVariants}
          >
            <h3 className="font-poppins font-semibold text-2xl mb-6 text-white">Our Mission</h3>
            <p className="text-gray-300 mb-6">
              To transform businesses through cutting-edge software solutions that leverage the power of artificial intelligence and machine learning. We believe technology should solve real problems and create tangible value.
            </p>
            <p className="text-gray-300 mb-6">
              Our team combines deep technical expertise with strategic thinking to deliver solutions that not only meet today's needs but anticipate tomorrow's challenges.
            </p>
            <div className="mt-8">
              <h4 className="font-poppins font-medium text-lg mb-4 text-white">Our Values</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-start">
                  <div className="text-accent-blue mr-3 mt-1"><i className="fas fa-lightbulb"></i></div>
                  <div>
                    <h5 className="font-medium text-white">Innovation</h5>
                    <p className="text-sm text-gray-400">Constantly pushing boundaries</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="text-accent-green mr-3 mt-1"><i className="fas fa-shield-alt"></i></div>
                  <div>
                    <h5 className="font-medium text-white">Quality</h5>
                    <p className="text-sm text-gray-400">Uncompromising excellence</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="text-accent-purple mr-3 mt-1"><i className="fas fa-users"></i></div>
                  <div>
                    <h5 className="font-medium text-white">Collaboration</h5>
                    <p className="text-sm text-gray-400">Partners in your success</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="text-accent-blue mr-3 mt-1"><i className="fas fa-rocket"></i></div>
                  <div>
                    <h5 className="font-medium text-white">Impact</h5>
                    <p className="text-sm text-gray-400">Creating meaningful change</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <h3 className="font-poppins font-semibold text-2xl mb-6 text-white">Our Technology Stack</h3>
            <div className="glass rounded-xl p-8">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-6">
                {/* Tech Stack Group: AI & ML */}
                <div>
                  <h4 className="text-accent-blue font-medium mb-3">AI & ML</h4>
                  <ul className="space-y-2 text-gray-300">
                    {technologies.ai.map((tech, index) => (
                      <li key={index} className="flex items-center">
                        <i className="fas fa-check text-accent-blue mr-2 text-xs"></i> {tech}
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* Tech Stack Group: Mobile */}
                <div>
                  <h4 className="text-accent-purple font-medium mb-3">Mobile</h4>
                  <ul className="space-y-2 text-gray-300">
                    {technologies.mobile.map((tech, index) => (
                      <li key={index} className="flex items-center">
                        <i className="fas fa-check text-accent-purple mr-2 text-xs"></i> {tech}
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* Tech Stack Group: Web */}
                <div>
                  <h4 className="text-accent-green font-medium mb-3">Web</h4>
                  <ul className="space-y-2 text-gray-300">
                    {technologies.web.map((tech, index) => (
                      <li key={index} className="flex items-center">
                        <i className="fas fa-check text-accent-green mr-2 text-xs"></i> {tech}
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* Tech Stack Group: Backend */}
                <div>
                  <h4 className="text-accent-blue font-medium mb-3">Backend</h4>
                  <ul className="space-y-2 text-gray-300">
                    {technologies.backend.map((tech, index) => (
                      <li key={index} className="flex items-center">
                        <i className="fas fa-check text-accent-blue mr-2 text-xs"></i> {tech}
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* Tech Stack Group: Cloud */}
                <div>
                  <h4 className="text-accent-purple font-medium mb-3">Cloud</h4>
                  <ul className="space-y-2 text-gray-300">
                    {technologies.cloud.map((tech, index) => (
                      <li key={index} className="flex items-center">
                        <i className="fas fa-check text-accent-purple mr-2 text-xs"></i> {tech}
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* Tech Stack Group: E-commerce */}
                <div>
                  <h4 className="text-accent-green font-medium mb-3">E-commerce</h4>
                  <ul className="space-y-2 text-gray-300">
                    {technologies.ecommerce.map((tech, index) => (
                      <li key={index} className="flex items-center">
                        <i className="fas fa-check text-accent-green mr-2 text-xs"></i> {tech}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;
