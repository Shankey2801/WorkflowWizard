import { useState, useRef, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';
import testimonials from '@/data/testimonials';

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [slideWidth, setSlideWidth] = useState(0);
  const trackRef = useRef<HTMLDivElement>(null);
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { once: true, amount: 0.2 });
  
  // Calculate slide width on mount and window resize
  useEffect(() => {
    const updateSliderDimensions = () => {
      if (trackRef.current && trackRef.current.children.length > 0) {
        const firstChild = trackRef.current.children[0] as HTMLElement;
        const slideWidthValue = firstChild.offsetWidth;
        const marginRight = parseInt(window.getComputedStyle(firstChild).marginRight);
        const marginLeft = parseInt(window.getComputedStyle(firstChild).marginLeft);
        
        setSlideWidth(slideWidthValue + marginRight + marginLeft);
      }
    };
    
    updateSliderDimensions();
    window.addEventListener('resize', updateSliderDimensions);
    
    return () => {
      window.removeEventListener('resize', updateSliderDimensions);
    };
  }, []);
  
  // Handle navigation
  const nextSlide = () => {
    setCurrentIndex(prev => (prev + 1) % testimonials.length);
  };
  
  const prevSlide = () => {
    setCurrentIndex(prev => (prev - 1 + testimonials.length) % testimonials.length);
  };
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.2,
        delayChildren: 0.3 
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  return (
    <section id="testimonials" className="py-20 md:py-32 relative overflow-hidden bg-[#0B1120]" ref={sectionRef}>
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-[#0F172A] to-transparent"></div>
      <div className="absolute right-0 top-1/3 w-96 h-96 bg-accent-blue rounded-full blur-[150px] opacity-10"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="inline-block font-poppins font-bold text-3xl sm:text-4xl mb-4 pb-2 border-b-2 border-accent-green">
            Client Testimonials
          </h2>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            See what our clients have to say about their experience working with Techmostphere.
          </p>
        </motion.div>
        
        <motion.div 
          className="relative"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          <div className="overflow-hidden">
            <motion.div 
              className="flex transition-transform duration-500 ease-out"
              style={{ transform: `translateX(-${currentIndex * slideWidth}px)` }}
              ref={trackRef}
            >
              {testimonials.map((testimonial) => (
                <motion.div 
                  key={testimonial.id}
                  className="w-full lg:w-1/2 flex-shrink-0 px-4"
                  variants={itemVariants}
                >
                  <div className="glass rounded-xl p-8 h-full">
                    <div className="flex items-center mb-6">
                      <div className="w-16 h-16 rounded-full overflow-hidden mr-4">
                        <img src={testimonial.image} alt={testimonial.name} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <h4 className="font-poppins font-semibold text-lg text-white">{testimonial.name}</h4>
                        <p className="text-accent-blue">{testimonial.position}, {testimonial.company}</p>
                      </div>
                    </div>
                    <div className="mb-4 text-yellow-400">
                      {[...Array(Math.floor(testimonial.rating))].map((_, i) => (
                        <i key={i} className="fas fa-star"></i>
                      ))}
                      {testimonial.rating % 1 !== 0 && (
                        <i className="fas fa-star-half-alt"></i>
                      )}
                    </div>
                    <blockquote className="text-gray-300 italic mb-6">
                      "{testimonial.quote}"
                    </blockquote>
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-gray-400">{testimonial.date}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
          
          <div className="flex justify-center mt-8 gap-4">
            <motion.button 
              className="w-10 h-10 glass rounded-full flex items-center justify-center hover:bg-accent-blue/20"
              onClick={prevSlide}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <i className="fas fa-chevron-left"></i>
            </motion.button>
            <motion.button 
              className="w-10 h-10 glass rounded-full flex items-center justify-center hover:bg-accent-blue/20"
              onClick={nextSlide}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <i className="fas fa-chevron-right"></i>
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;
