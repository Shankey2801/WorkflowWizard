import { useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

// Form validation schema
const contactSchema = z.object({
  name: z.string().min(2, { message: 'Name must be at least 2 characters' }),
  email: z.string().email({ message: 'Please enter a valid email' }),
  company: z.string().optional(),
  service: z.string().optional(),
  message: z.string().min(10, { message: 'Message must be at least 10 characters' })
});

type ContactFormData = z.infer<typeof contactSchema>;

const Contact = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, amount: 0.2 });
  const { toast } = useToast();
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema)
  });
  
  const onSubmit = async (data: ContactFormData) => {
    setIsSubmitting(true);
    
    try {
      await apiRequest('POST', '/api/contact', data);
      
      toast({
        title: "Message Sent!",
        description: "Thank you for contacting us. We'll get back to you soon.",
        variant: "default",
      });
      
      reset();
    } catch (error) {
      console.error('Form submission error:', error);
      
      toast({
        title: "Something went wrong",
        description: "Your message couldn't be sent. Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  return (
    <section id="contact" className="py-20 md:py-32 relative overflow-hidden" ref={sectionRef}>
      <div className="absolute left-0 bottom-0 w-96 h-96 bg-accent-green rounded-full blur-[150px] opacity-10"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="inline-block font-poppins font-bold text-3xl sm:text-4xl mb-4 pb-2 border-b-2 border-accent-pink">
            Get In Touch
          </h2>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            Ready to transform your ideas into intelligent software? Let's start a conversation.
          </p>
        </motion.div>
        
        <motion.div 
          className="grid grid-cols-1 lg:grid-cols-2 gap-12"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {/* Contact Form */}
          <motion.div className="glass rounded-xl p-8" variants={itemVariants}>
            <h3 className="font-poppins font-semibold text-2xl mb-6 text-white">Send Us a Message</h3>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="name" className="block text-gray-300 mb-2">Name</label>
                  <input 
                    type="text" 
                    id="name" 
                    {...register('name')}
                    className="w-full bg-[#1E293B] border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-accent-pink" 
                  />
                  {errors.name && <p className="text-red-400 text-sm mt-1">{errors.name.message}</p>}
                </div>
                <div>
                  <label htmlFor="email" className="block text-gray-300 mb-2">Email</label>
                  <input 
                    type="email" 
                    id="email" 
                    {...register('email')}
                    className="w-full bg-[#1E293B] border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-accent-orange" 
                  />
                  {errors.email && <p className="text-red-400 text-sm mt-1">{errors.email.message}</p>}
                </div>
              </div>
              
              <div className="mb-6">
                <label htmlFor="company" className="block text-gray-300 mb-2">Company</label>
                <input 
                  type="text" 
                  id="company" 
                  {...register('company')}
                  className="w-full bg-[#1E293B] border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-accent-purple"
                />
              </div>
              
              <div className="mb-6">
                <label htmlFor="service" className="block text-gray-300 mb-2">Services Interested In</label>
                <select 
                  id="service" 
                  {...register('service')}
                  className="w-full bg-[#1E293B] border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-accent-orange"
                >
                  <option value="">Select a service</option>
                  <option value="ai">AI & Machine Learning</option>
                  <option value="nlp">Natural Language Processing</option>
                  <option value="custom">Custom Software</option>
                  <option value="mobile">Mobile App Development</option>
                  <option value="web">Web Development</option>
                  <option value="shopify">Shopify Development</option>
                  <option value="odoo">Odoo Implementation</option>
                </select>
              </div>
              
              <div className="mb-6">
                <label htmlFor="message" className="block text-gray-300 mb-2">Message</label>
                <textarea 
                  id="message" 
                  rows={5} 
                  {...register('message')}
                  className="w-full bg-[#1E293B] border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-accent-purple" 
                ></textarea>
                {errors.message && <p className="text-red-400 text-sm mt-1">{errors.message.message}</p>}
              </div>
              
              <motion.button 
                type="submit" 
                className="gradient-border w-full px-6 py-3 bg-[#0B1120] hover:bg-[#172032] font-medium rounded-lg transition-all transform hover:scale-105 disabled:opacity-70"
                disabled={isSubmitting}
                whileHover={{ scale: isSubmitting ? 1 : 1.03 }}
                whileTap={{ scale: isSubmitting ? 1 : 0.98 }}
              >
                {isSubmitting ? 'Sending...' : 'Send Message'}
              </motion.button>
            </form>
          </motion.div>
          
          {/* Contact Info */}
          <motion.div variants={itemVariants}>
            <motion.div className="glass rounded-xl p-8 mb-8" variants={itemVariants}>
              <h3 className="font-poppins font-semibold text-2xl mb-6 text-white">Contact Information</h3>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-10 h-10 rounded-full glass flex items-center justify-center mr-4">
                    <i className="fas fa-envelope text-accent-pink"></i>
                  </div>
                  <div>
                    <h4 className="font-medium text-white mb-1">Email Us At</h4>
                    <p className="text-gray-300">Sales@techmostphere.com</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="w-10 h-10 rounded-full glass flex items-center justify-center mr-4">
                    <i className="fas fa-phone-alt text-accent-green"></i>
                  </div>
                  <div>
                    <h4 className="font-medium text-white mb-1">Call Us</h4>
                    <p className="text-gray-300">+91-8882069093</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="w-10 h-10 rounded-full glass flex items-center justify-center mr-4">
                    <i className="fas fa-map-marker-alt text-accent-purple"></i>
                  </div>
                  <div>
                    <h4 className="font-medium text-white mb-1">Office Location</h4>
                    <p className="text-gray-300">B-13, Sector - 49<br />Noida, U.P. India, 201301</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div className="glass rounded-xl p-8" variants={itemVariants}>
              <h3 className="font-poppins font-semibold text-2xl mb-6 text-white">Connect With Us</h3>
              <div className="flex space-x-4 mb-8">
                <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-accent-pink/20 transition-colors">
                  <i className="fab fa-linkedin-in text-accent-pink"></i>
                </a>
                <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-accent-orange/20 transition-colors">
                  <i className="fab fa-twitter text-accent-orange"></i>
                </a>
                <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-accent-purple/20 transition-colors">
                  <i className="fab fa-github text-accent-purple"></i>
                </a>
                <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-accent-orange/20 transition-colors">
                  <i className="fab fa-instagram text-accent-orange"></i>
                </a>
              </div>
              
              <h4 className="font-medium text-white mb-4">Newsletter</h4>
              <p className="text-gray-300 mb-4">Subscribe to our newsletter for the latest tech insights and updates.</p>
              <form className="flex">
                <input 
                  type="email" 
                  placeholder="Your email address" 
                  className="flex-grow bg-[#1E293B] border border-gray-700 rounded-l-lg px-4 py-2 text-white focus:outline-none focus:border-accent-pink"
                />
                <button 
                  type="submit" 
                  className="bg-accent-pink hover:bg-accent-pink/90 text-white px-4 py-2 rounded-r-lg"
                >
                  <i className="fas fa-paper-plane"></i>
                </button>
              </form>
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Contact;
