import { motion } from 'framer-motion';

const Footer = () => {
  return (
    <footer className="py-12 relative bg-[#0B1120]">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-accent-blue/50 to-transparent"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <span className="text-accent-blue text-2xl"><i className="fas fa-cube"></i></span>
              <span className="font-poppins font-bold text-lg text-white">Techmostphere</span>
            </div>
            <p className="text-gray-400 mb-6">
              Transforming ideas into intelligent software through cutting-edge technology and innovation.
            </p>
          </div>
          
          <div>
            <h4 className="font-poppins font-semibold text-lg text-white mb-6">Services</h4>
            <ul className="space-y-3 text-gray-400">
              <li><a href="#" className="hover:text-accent-blue transition-colors">AI & Machine Learning</a></li>
              <li><a href="#" className="hover:text-accent-blue transition-colors">Natural Language Processing</a></li>
              <li><a href="#" className="hover:text-accent-blue transition-colors">Custom Software</a></li>
              <li><a href="#" className="hover:text-accent-blue transition-colors">Mobile App Development</a></li>
              <li><a href="#" className="hover:text-accent-blue transition-colors">Web Development</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-poppins font-semibold text-lg text-white mb-6">Company</h4>
            <ul className="space-y-3 text-gray-400">
              <li><a href="#about" className="hover:text-accent-blue transition-colors">About Us</a></li>
              <li><a href="#portfolio" className="hover:text-accent-blue transition-colors">Portfolio</a></li>
              <li><a href="#" className="hover:text-accent-blue transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-accent-blue transition-colors">Blog</a></li>
              <li><a href="#contact" className="hover:text-accent-blue transition-colors">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-poppins font-semibold text-lg text-white mb-6">Legal</h4>
            <ul className="space-y-3 text-gray-400">
              <li><a href="#" className="hover:text-accent-blue transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-accent-blue transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-accent-blue transition-colors">Cookie Policy</a></li>
            </ul>
          </div>
        </div>
        
        <motion.div 
          className="border-t border-gray-800 pt-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          viewport={{ once: true }}
        >
          <div className="flex flex-col md:flex-row items-center justify-between">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} Techmostphere. All rights reserved.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors">
                <i className="fab fa-linkedin-in"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors">
                <i className="fab fa-github"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors">
                <i className="fab fa-instagram"></i>
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;
