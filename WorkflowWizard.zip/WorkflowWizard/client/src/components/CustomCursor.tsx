import { useEffect, useState } from 'react';

const CustomCursor = () => {
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    // Only show custom cursor on larger screens
    const checkScreenSize = () => {
      setIsVisible(window.innerWidth >= 1024);
    };
    
    // Initial check
    checkScreenSize();
    
    // Add cursor movement handlers
    const onMouseMove = (e: MouseEvent) => {
      const cursor = document.querySelector('.custom-cursor') as HTMLElement;
      const cursorFollower = document.querySelector('.custom-cursor-follower') as HTMLElement;
      
      if (cursor && cursorFollower) {
        cursor.style.left = `${e.clientX}px`;
        cursor.style.top = `${e.clientY}px`;
        
        // Add delay for follower for smooth effect
        setTimeout(() => {
          cursorFollower.style.left = `${e.clientX}px`;
          cursorFollower.style.top = `${e.clientY}px`;
        }, 70);
      }
    };
    
    // Add effects for interactive elements
    const addInteractiveEffects = () => {
      const interactiveElements = document.querySelectorAll('a, button, input, textarea, select');
      const cursor = document.querySelector('.custom-cursor') as HTMLElement;
      const cursorFollower = document.querySelector('.custom-cursor-follower') as HTMLElement;
      
      if (!cursor || !cursorFollower) return;
      
      interactiveElements.forEach(el => {
        el.addEventListener('mouseenter', () => {
          cursor.style.transform = 'translate(-50%, -50%) scale(1.5)';
          cursorFollower.style.transform = 'translate(-50%, -50%) scale(0.75)';
          cursorFollower.style.opacity = '0.5';
        });
        
        el.addEventListener('mouseleave', () => {
          cursor.style.transform = 'translate(-50%, -50%) scale(1)';
          cursorFollower.style.transform = 'translate(-50%, -50%) scale(1)';
          cursorFollower.style.opacity = '1';
        });
      });
    };
    
    // Add event listeners
    window.addEventListener('resize', checkScreenSize);
    if (isVisible) {
      document.addEventListener('mousemove', onMouseMove);
      addInteractiveEffects();
    }
    
    // Cleanup event listeners
    return () => {
      window.removeEventListener('resize', checkScreenSize);
      document.removeEventListener('mousemove', onMouseMove);
    };
  }, [isVisible]);

  if (!isVisible) return null;
  
  return (
    <>
      <div className="custom-cursor"></div>
      <div className="custom-cursor-follower"></div>
    </>
  );
};

export default CustomCursor;
