import { motion } from 'framer-motion';
import ParticlesBackground from './ParticlesBackground';

const Hero = () => {
  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <ParticlesBackground id="particles-js" />
      
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0B1120] via-[#0F172A] to-[#1E293B]"></div>
      <div className="absolute top-40 left-10 w-72 h-72 bg-accent-purple rounded-full blur-[120px] opacity-20"></div>
      <div className="absolute bottom-40 right-10 w-72 h-72 bg-accent-blue rounded-full blur-[120px] opacity-20"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.h1 
            className="font-poppins font-bold text-4xl sm:text-5xl md:text-6xl mb-6 leading-tight"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <span className="text-white">Transforming Ideas into</span>{' '}
            <span className="font-extrabold tracking-wide text-accent-blue">
              Intelligent Software
            </span>
          </motion.h1>
          
          <motion.p 
            className="text-lg sm:text-xl text-gray-300 mb-8 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Cutting-edge solutions in AI, ML, NLP, custom software, mobile apps and web development 
            for forward-thinking businesses.
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <a href="#contact" className="w-full sm:w-auto gradient-border px-6 py-3 bg-[#0B1120] hover:bg-[#172032] font-medium rounded-lg transition-all transform hover:scale-105">
              Get a Free Consultation
            </a>
            <a href="#portfolio" className="w-full sm:w-auto px-6 py-3 bg-[#1E293B] hover:bg-[#172032] font-medium rounded-lg border border-accent-blue/30 transition-all transform hover:scale-105">
              Explore Our Work
            </a>
          </motion.div>
        </motion.div>
        
        <motion.div 
          className="mt-16 flex justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.2 }}
        >
          <motion.div 
            className="glass p-4 rounded-full"
            animate={{ y: [0, -10, 0] }}
            transition={{ repeat: Infinity, duration: 1.5, repeatType: "reverse" }}
          >
            <a href="#services" className="text-accent-blue">
              <i className="fas fa-chevron-down"></i>
            </a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
