import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import services from '@/data/services';

const Services = () => {
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, amount: 0.2 });
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  return (
    <section id="services" className="py-20 md:py-32 relative overflow-hidden" ref={sectionRef}>
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-[#0F172A] to-transparent"></div>
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-[#0F172A] to-transparent"></div>
      <div className="absolute -left-64 top-1/4 w-96 h-96 bg-accent-blue rounded-full blur-[150px] opacity-10"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="inline-block font-poppins font-bold text-3xl sm:text-4xl mb-4 pb-2 border-b-2 border-accent-green">
            Our Services
          </h2>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            We specialize in cutting-edge technologies to deliver solutions that drive your business forward.
          </p>
        </motion.div>
        
        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {services.map((service) => (
            <motion.div 
              key={service.id}
              className="service-card glass rounded-xl p-6 flex flex-col"
              variants={itemVariants}
            >
              <div className={`mb-5 text-4xl ${service.iconColor}`}>
                <i className={service.icon}></i>
              </div>
              <h3 className="font-poppins font-semibold text-xl mb-3">{service.title}</h3>
              <p className="text-gray-400 flex-grow mb-4">{service.description}</p>
              <a 
                href="#contact" 
                className={`${service.iconColor} font-medium flex items-center`}
              >
                Learn more <i className="fas fa-arrow-right ml-2 text-sm"></i>
              </a>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Services;
