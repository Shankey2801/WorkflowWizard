import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import portfolioData from '@/data/portfolio';
import { usePortfolioFilter } from '@/hooks/usePortfolioFilter';

const Portfolio = () => {
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, amount: 0.2 });
  const { activeFilter, filteredItems, handleFilterClick } = usePortfolioFilter(portfolioData);
  
  // Animations
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: { 
        type: "spring", 
        stiffness: 80,
        damping: 15
      }
    }
  };

  return (
    <section id="portfolio" className="py-20 md:py-32 relative overflow-hidden bg-[#0B1120]" ref={sectionRef}>
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-[#0F172A] to-transparent"></div>
      <div className="absolute -right-64 top-1/3 w-96 h-96 bg-accent-green rounded-full blur-[150px] opacity-10"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="inline-block font-poppins font-bold text-3xl sm:text-4xl mb-4 pb-2 border-b-2 border-accent-blue">
            Our Portfolio
          </h2>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            Explore our recent projects that showcase our expertise across different technologies.
          </p>
        </motion.div>
        
        <motion.div 
          className="flex flex-wrap justify-center mb-10 gap-4"
          initial={{ opacity: 0, y: 10 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <button 
            className={`portfolio-filter px-5 py-2 rounded-full glass hover:bg-accent-blue/20 ${activeFilter === 'all' ? 'bg-accent-blue/20' : ''}`} 
            onClick={() => handleFilterClick('all')}
          >
            All Projects
          </button>
          <button 
            className={`portfolio-filter px-5 py-2 rounded-full glass hover:bg-accent-blue/20 ${activeFilter === 'ai' ? 'bg-accent-blue/20' : ''}`}
            onClick={() => handleFilterClick('ai')}
          >
            AI & ML
          </button>
          <button 
            className={`portfolio-filter px-5 py-2 rounded-full glass hover:bg-accent-blue/20 ${activeFilter === 'mobile' ? 'bg-accent-blue/20' : ''}`}
            onClick={() => handleFilterClick('mobile')}
          >
            Mobile Apps
          </button>
          <button 
            className={`portfolio-filter px-5 py-2 rounded-full glass hover:bg-accent-blue/20 ${activeFilter === 'web' ? 'bg-accent-blue/20' : ''}`}
            onClick={() => handleFilterClick('web')}
          >
            Web Development
          </button>
          <button 
            className={`portfolio-filter px-5 py-2 rounded-full glass hover:bg-accent-blue/20 ${activeFilter === 'ecommerce' ? 'bg-accent-blue/20' : ''}`}
            onClick={() => handleFilterClick('ecommerce')}
          >
            E-Commerce
          </button>
        </motion.div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {filteredItems.map((item) => (
            <motion.div 
              key={item.id}
              className="portfolio-item glass rounded-xl overflow-hidden"
              variants={itemVariants}
              layout
            >
              <div className="relative h-56 overflow-hidden">
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
                <div className={`absolute top-3 right-3 ${item.categoryColor} text-xs font-medium px-2 py-1 rounded`}>
                  {item.categoryLabel}
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-poppins font-semibold text-xl mb-2">{item.title}</h3>
                <p className="text-gray-400 mb-4">{item.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {item.technologies.map((tech, index) => (
                    <span key={index} className="text-xs bg-[#1E293B] px-2 py-1 rounded">{tech}</span>
                  ))}
                </div>
                <a href="#" className={`text-${item.category === 'ai' ? 'accent-blue' : item.category === 'mobile' ? 'accent-purple' : 'accent-green'} font-medium flex items-center`}>
                  View Case Study <i className="fas fa-arrow-right ml-2 text-sm"></i>
                </a>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Portfolio;
