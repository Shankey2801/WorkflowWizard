import { useState, useEffect, useCallback } from 'react';
import { PortfolioItem } from '@/data/portfolio';

type FilterCategory = 'all' | 'ai' | 'mobile' | 'web' | 'ecommerce';

export const usePortfolioFilter = (items: PortfolioItem[]) => {
  const [activeFilter, setActiveFilter] = useState<FilterCategory>('all');
  const [filteredItems, setFilteredItems] = useState<PortfolioItem[]>(items);
  
  // Apply filter whenever activeFilter changes
  useEffect(() => {
    if (activeFilter === 'all') {
      setFilteredItems(items);
    } else {
      const filtered = items.filter(item => item.category === activeFilter);
      setFilteredItems(filtered);
    }
  }, [activeFilter, items]);
  
  // Handle filter click
  const handleFilterClick = useCallback((category: FilterCategory) => {
    setActiveFilter(category);
  }, []);
  
  return {
    activeFilter,
    filteredItems,
    handleFilterClick
  };
};
