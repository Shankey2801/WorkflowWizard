export interface PortfolioItem {
  id: string;
  title: string;
  description: string;
  category: 'ai' | 'mobile' | 'web' | 'ecommerce';
  categoryLabel: string;
  categoryColor: string;
  image: string;
  technologies: string[];
}

const portfolio: PortfolioItem[] = [
  {
    id: 'ai-analytics',
    title: 'Predictive Analytics Platform',
    description: 'AI-powered analytics solution for a fintech company that predicts market trends.',
    category: 'ai',
    categoryLabel: 'AI & ML',
    categoryColor: 'bg-accent-blue/80',
    image: 'https://images.unsplash.com/photo-1577760258779-e787a1733016',
    technologies: ['TensorFlow', 'Python', 'React']
  },
  {
    id: 'health-app',
    title: 'Health Tracking App',
    description: 'Cross-platform mobile application for tracking health metrics and wellness activities.',
    category: 'mobile',
    categoryLabel: 'Mobile Apps',
    categoryColor: 'bg-accent-purple/80',
    image: 'https://images.unsplash.com/photo-1551650975-87deedd944c3',
    technologies: ['Flutter', 'Firebase', 'ML Kit']
  },
  {
    id: 'collaboration',
    title: 'Collaboration Platform',
    description: 'Real-time collaboration tool for remote teams with advanced file sharing features.',
    category: 'web',
    categoryLabel: 'Web Development',
    categoryColor: 'bg-accent-green/80',
    image: 'https://images.unsplash.com/photo-1555949963-ff9fe0c870eb',
    technologies: ['Next.js', 'WebRTC', 'GraphQL']
  },
  {
    id: 'ai-chatbot',
    title: 'AI Customer Service Chatbot',
    description: 'NLP-powered customer service solution that handles inquiries for a retail chain.',
    category: 'ai',
    categoryLabel: 'AI & ML',
    categoryColor: 'bg-accent-blue/80',
    image: 'https://images.unsplash.com/photo-1535378917042-10a22c95931a',
    technologies: ['NLP', 'Python', 'Node.js']
  },
  {
    id: 'shopify-store',
    title: 'Custom Shopify Solution',
    description: 'Personalized e-commerce platform with custom checkout and inventory management.',
    category: 'ecommerce',
    categoryLabel: 'E-Commerce',
    categoryColor: 'bg-accent-purple/80',
    image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d',
    technologies: ['Shopify', 'Liquid', 'JavaScript']
  },
  {
    id: 'payment-app',
    title: 'Secure Payment Application',
    description: 'Mobile payment solution with biometric authentication for a banking client.',
    category: 'mobile',
    categoryLabel: 'Mobile Apps',
    categoryColor: 'bg-accent-green/80',
    image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c',
    technologies: ['React Native', 'Blockchain', 'Biometrics']
  }
];

export default portfolio;
