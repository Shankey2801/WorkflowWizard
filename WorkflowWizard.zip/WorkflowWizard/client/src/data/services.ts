interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  iconColor: string;
}

const services: Service[] = [
  {
    id: 'ai-ml',
    title: 'AI & Machine Learning',
    description: 'Custom AI solutions for predictive analytics, natural language processing, and intelligent automation.',
    icon: 'fas fa-brain',
    iconColor: 'text-accent-blue'
  },
  {
    id: 'nlp',
    title: 'Natural Language Processing',
    description: 'Advanced text analysis, sentiment detection, and chatbot development for enhanced user engagement.',
    icon: 'fas fa-comment-dots',
    iconColor: 'text-accent-purple'
  },
  {
    id: 'custom-software',
    title: 'Custom Software',
    description: 'Tailored software solutions designed specifically for your business needs and workflows.',
    icon: 'fas fa-code',
    iconColor: 'text-accent-green'
  },
  {
    id: 'mobile-app',
    title: 'Mobile App Development',
    description: 'Cross-platform iOS and Android applications using Flutter, React Native, and native technologies.',
    icon: 'fas fa-mobile-alt',
    iconColor: 'text-accent-blue'
  },
  {
    id: 'web-dev',
    title: 'Web Development',
    description: 'Responsive, high-performance websites and web applications using the latest technologies.',
    icon: 'fas fa-globe',
    iconColor: 'text-accent-purple'
  },
  {
    id: 'shopify',
    title: 'Shopify Development',
    description: 'Custom Shopify solutions, themes, and apps to enhance your e-commerce presence.',
    icon: 'fas fa-shopping-cart',
    iconColor: 'text-accent-green'
  },
  {
    id: 'odoo',
    title: 'Odoo Implementation',
    description: 'End-to-end Odoo implementation services for streamlined business operations and management.',
    icon: 'fas fa-cogs',
    iconColor: 'text-accent-blue'
  },
  {
    id: 'automation',
    title: 'Workflow Automation',
    description: 'Automate repetitive tasks and streamline workflows for improved efficiency and productivity.',
    icon: 'fas fa-robot',
    iconColor: 'text-accent-purple'
  }
];

export default services;
