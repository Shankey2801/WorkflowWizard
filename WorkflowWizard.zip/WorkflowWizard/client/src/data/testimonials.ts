interface Testimonial {
  id: string;
  name: string;
  position: string;
  company: string;
  image: string;
  quote: string;
  rating: number;
  date: string;
}

const testimonials: Testimonial[] = [
  {
    id: 'testimonial1',
    name: 'Sarah Johnson',
    position: 'CTO',
    company: 'FinTech Innovations',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330',
    quote: 'Techmostphere delivered an AI solution that transformed our data analysis capabilities. Their team\'s expertise in machine learning algorithms and commitment to understanding our specific needs resulted in a system that exceeded our expectations.',
    rating: 5,
    date: 'June 2023'
  },
  {
    id: 'testimonial2',
    name: 'Michael Chen',
    position: 'Founder',
    company: 'MobileHealth',
    image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a',
    quote: 'We partnered with Techmostphere to develop our health tracking mobile app, and the results were outstanding. They seamlessly integrated complex features while maintaining an intuitive user experience. The app has received excellent feedback from our users.',
    rating: 5,
    date: 'August 2023'
  },
  {
    id: 'testimonial3',
    name: 'Rebecca Martinez',
    position: 'Director of E-Commerce',
    company: 'LuxStyles',
    image: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e',
    quote: 'Our Shopify customization project with Techmostphere has been a game-changer for our online store. They built a seamless shopping experience with personalized recommendations that has significantly improved our conversion rates and customer satisfaction.',
    rating: 4.5,
    date: 'September 2023'
  }
];

export default testimonials;
