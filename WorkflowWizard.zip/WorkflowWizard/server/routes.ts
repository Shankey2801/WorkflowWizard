import express, { type Express } from "express";
import type { Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create API routes
  const apiRouter = express.Router();
  
  // Contact form submission
  apiRouter.post('/contact', async (req: Request, res: Response) => {
    try {
      // Validate the request body
      const contactData = insertContactSchema.parse(req.body);
      
      // Store the message in the database
      const timestamp = new Date().toISOString();
      
      // Save to database
      const savedMessage = await storage.createContactMessage({
        ...contactData,
        createdAt: timestamp
      });
      
      console.log('Contact form saved to database:', savedMessage);
      
      // Return success response
      return res.status(200).json({ 
        success: true, 
        message: 'Message received successfully' 
      });
    } catch (error) {
      // Handle validation errors
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          success: false, 
          message: 'Validation error', 
          errors: validationError.details
        });
      }
      
      // Handle other errors
      console.error('Contact form error:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'An error occurred while processing your request' 
      });
    }
  });
  
  // Newsletter subscription
  apiRouter.post('/newsletter', (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      
      // Validate email
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return res.status(400).json({
          success: false,
          message: 'Please provide a valid email address'
        });
      }
      
      // For demo purposes, just log the subscription
      console.log('Newsletter subscription:', email);
      
      return res.status(200).json({
        success: true,
        message: 'Successfully subscribed to newsletter'
      });
    } catch (error) {
      console.error('Newsletter subscription error:', error);
      return res.status(500).json({
        success: false,
        message: 'An error occurred while processing your request'
      });
    }
  });

  // Get all contact messages (protected endpoint, would require authentication in production)
  apiRouter.get('/contact-messages', async (_req: Request, res: Response) => {
    try {
      const messages = await storage.getAllContactMessages();
      return res.status(200).json({ 
        success: true, 
        data: messages
      });
    } catch (error) {
      console.error('Error fetching contact messages:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'An error occurred while retrieving messages' 
      });
    }
  });
  
  // Mount the API router
  app.use('/api', apiRouter);

  const httpServer = createServer(app);

  return httpServer;
}
